import React, { Component } from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import FeatherIcon from "react-native-vector-icons/Feather";
import EntypoIcon from "react-native-vector-icons/Entypo";

function LoginPage(props) {
  return (
    <View style={styles.container}>
      <View style={styles.rect2}>
        <View style={styles.icon4Row}>
          <FeatherIcon name="mail" style={styles.icon4}></FeatherIcon>
          <Text style={styles.emailId}>Email ID</Text>
        </View>
      </View>
      <View style={styles.rect1}>
        <View style={styles.icon5Row}>
          <FeatherIcon name="lock" style={styles.icon5}></FeatherIcon>
          <Text style={styles.password}>Password</Text>
          <EntypoIcon name="eye-with-line" style={styles.icon}></EntypoIcon>
        </View>
      </View>
      <View style={styles.rect3}>
        <Text style={styles.login}>Login</Text>
      </View>
      <Text style={styles.forgotPassword}>Forgot Password?</Text>
      <Text style={styles.loremIpsum}>Don&#39;t have an account?</Text>
      <Text style={styles.registerNow}>Register now</Text>
      <Image
        source={require("../assets/images/Logo_transparent_bg.png")}
        resizeMode="contain"
        style={styles.image}
      ></Image>
      <Text style={styles.loremIpsum2}>Welcome to SpeedyWash India</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(245,245,245,1)",
    opacity: 0.9
  },
  rect2: {
    width: 265,
    height: 50,
    backgroundColor: "rgba(255,255,255,1)",
    borderRadius: 10,
    flexDirection: "row",
    marginTop: 320,
    alignSelf: "center"
  },
  icon4: {
    color: "rgba(128,128,128,1)",
    fontSize: 25,
    height: 26,
    width: 26
  },
  emailId: {
    fontFamily: "roboto-regular",
    color: "#121212",
    height: 21,
    width: 72,
    fontSize: 18,
    marginLeft: 9
  },
  icon4Row: {
    height: 26,
    flexDirection: "row",
    flex: 1,
    marginRight: 148,
    marginLeft: 10,
    marginTop: 13
  },
  rect1: {
    width: 265,
    height: 50,
    backgroundColor: "rgba(255,255,255,1)",
    borderRadius: 10,
    flexDirection: "row",
    marginTop: 35,
    marginLeft: 47
  },
  icon5: {
    color: "rgba(128,128,128,1)",
    fontSize: 25,
    height: 25,
    width: 25,
    marginTop: 2
  },
  password: {
    fontFamily: "roboto-regular",
    color: "#121212",
    fontSize: 18,
    alignSelf: "flex-end",
    marginLeft: 10,
    marginBottom: 3
  },
  icon: {
    color: "rgba(128,128,128,1)",
    fontSize: 25,
    height: 27,
    width: 25,
    marginLeft: 93
  },
  icon5Row: {
    height: 27,
    flexDirection: "row",
    flex: 1,
    marginRight: 22,
    marginLeft: 11,
    marginTop: 12
  },
  rect3: {
    width: 265,
    height: 50,
    backgroundColor: "rgba(0,107,173,1)",
    borderRadius: 10,
    marginTop: 45,
    marginLeft: 47
  },
  login: {
    fontFamily: "roboto-regular",
    color: "rgba(255,255,255,1)",
    height: 21,
    width: 57,
    fontSize: 18,
    textAlign: "center",
    marginTop: 14,
    marginLeft: 105
  },
  forgotPassword: {
    fontFamily: "roboto-regular",
    color: "rgba(0,107,173,1)",
    height: 26,
    width: 125,
    marginTop: -87,
    marginLeft: 202
  },
  loremIpsum: {
    fontFamily: "roboto-regular",
    color: "rgba(18,18,18,1)",
    height: 18,
    width: 155,
    marginTop: 121,
    alignSelf: "center"
  },
  registerNow: {
    fontFamily: "roboto-regular",
    color: "rgba(0,107,173,1)",
    height: 18,
    width: 91,
    textAlign: "center",
    marginTop: 5,
    alignSelf: "center"
  },
  image: {
    width: 200,
    height: 200,
    marginTop: -589,
    alignSelf: "center"
  },
  loremIpsum2: {
    fontFamily: "roboto-700",
    color: "rgba(0,107,173,1)",
    height: 22,
    width: 257,
    fontSize: 18,
    marginTop: 6,
    alignSelf: "center"
  }
});

export default LoginPage;
