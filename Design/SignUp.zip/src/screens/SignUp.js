import React, { Component } from "react";
import { StyleSheet, View, Image, Text } from "react-native";
import MaterialFixedLabelTextbox5 from "../components/MaterialFixedLabelTextbox5";
import MaterialFixedLabelTextbox4 from "../components/MaterialFixedLabelTextbox4";
import MaterialFixedLabelTextbox3 from "../components/MaterialFixedLabelTextbox3";
import MaterialFixedLabelTextbox2 from "../components/MaterialFixedLabelTextbox2";
import MaterialCheckboxWithLabel1 from "../components/MaterialCheckboxWithLabel1";

function SignUp(props) {
  return (
    <View style={styles.container}>
      <View style={styles.rect5}>
        <MaterialFixedLabelTextbox5
          style={styles.materialFixedLabelTextbox5}
        ></MaterialFixedLabelTextbox5>
      </View>
      <View style={styles.rect4}>
        <MaterialFixedLabelTextbox4
          style={styles.materialFixedLabelTextbox4}
        ></MaterialFixedLabelTextbox4>
      </View>
      <View style={styles.rect3}>
        <MaterialFixedLabelTextbox3
          style={styles.materialFixedLabelTextbox3}
        ></MaterialFixedLabelTextbox3>
      </View>
      <View style={styles.rect1}>
        <MaterialFixedLabelTextbox2
          style={styles.materialFixedLabelTextbox2}
        ></MaterialFixedLabelTextbox2>
      </View>
      <Image
        source={require("../assets/images/Logo_transparent_bg.png")}
        resizeMode="contain"
        style={styles.image1}
      ></Image>
      <View style={styles.login1Stack}>
        <Text style={styles.login1}>Login</Text>
        <View style={styles.rect2}>
          <Text style={styles.createAccount}>Create Account</Text>
        </View>
      </View>
      <MaterialCheckboxWithLabel1
        style={styles.materialCheckboxWithLabel1}
      ></MaterialCheckboxWithLabel1>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(245,245,245,1)"
  },
  rect5: {
    width: 325,
    height: 50,
    backgroundColor: "rgba(220,242,253,1)",
    borderRadius: 10,
    marginTop: 460,
    alignSelf: "center"
  },
  materialFixedLabelTextbox5: {
    height: 42,
    width: 298,
    marginLeft: 12
  },
  rect4: {
    width: 325,
    height: 50,
    backgroundColor: "rgba(220,242,253,1)",
    borderRadius: 10,
    marginTop: -110,
    marginLeft: 18
  },
  materialFixedLabelTextbox4: {
    height: 39,
    width: 298,
    marginTop: 3,
    marginLeft: 12
  },
  rect3: {
    width: 325,
    height: 50,
    backgroundColor: "rgba(220,242,253,1)",
    borderRadius: 10,
    marginTop: -108,
    marginLeft: 17
  },
  materialFixedLabelTextbox3: {
    height: 38,
    width: 298,
    marginTop: 4,
    marginLeft: 13
  },
  rect1: {
    width: 325,
    height: 50,
    backgroundColor: "rgba(220,242,253,1)",
    borderRadius: 10,
    marginTop: -109,
    marginLeft: 18
  },
  materialFixedLabelTextbox2: {
    height: 38,
    width: 298,
    marginTop: 3,
    marginLeft: 12
  },
  image1: {
    width: 200,
    height: 200,
    marginTop: -287,
    alignSelf: "center"
  },
  login1: {
    top: 15,
    left: 105,
    position: "absolute",
    fontFamily: "roboto-regular",
    color: "rgba(255,255,255,1)",
    height: 21,
    width: 57,
    fontSize: 18,
    textAlign: "center"
  },
  rect2: {
    top: 0,
    width: 265,
    height: 50,
    position: "absolute",
    backgroundColor: "rgba(0,107,173,1)",
    borderRadius: 10,
    left: 0
  },
  createAccount: {
    fontFamily: "roboto-regular",
    color: "rgba(255,255,255,1)",
    height: 21,
    width: 127,
    fontSize: 18,
    textAlign: "center",
    marginTop: 15,
    marginLeft: 69
  },
  login1Stack: {
    width: 265,
    height: 50,
    marginTop: 324,
    marginLeft: 47
  },
  materialCheckboxWithLabel1: {
    height: 40,
    width: 310,
    marginTop: -104,
    alignSelf: "center"
  }
});

export default SignUp;
