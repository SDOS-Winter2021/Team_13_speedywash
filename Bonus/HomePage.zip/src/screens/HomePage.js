import React, { Component } from "react";
import { StyleSheet, View, ScrollView, Text, Image } from "react-native";
import MaterialHeader4 from "../components/MaterialHeader4";
import MaterialCardWithTextOverImage1 from "../components/MaterialCardWithTextOverImage1";
import MaterialBasicFooter3 from "../components/MaterialBasicFooter3";

function HomePage(props) {
  return (
    <View style={styles.container}>
      <View style={styles.materialHeader4Column}>
        <MaterialHeader4 style={styles.materialHeader4}></MaterialHeader4>
        <View style={styles.scrollArea}>
          <ScrollView
            contentContainerStyle={styles.scrollArea_contentContainerStyle}
          >
            <MaterialCardWithTextOverImage1
              style={styles.materialCardWithTextOverImage1}
            ></MaterialCardWithTextOverImage1>
            <Text style={styles.selectService}>Select Service</Text>
            <View style={styles.rect5}>
              <View style={styles.image5Row}>
                <Image
                  source={require("../assets/images/sample.png")}
                  resizeMode="contain"
                  style={styles.image5}
                ></Image>
                <Text style={styles.carpetCleaning}>Carpet Cleaning</Text>
              </View>
            </View>
            <View style={styles.rect6}>
              <View style={styles.sofaDrycleaningRow}>
                <Text style={styles.sofaDrycleaning}>Sofa Drycleaning</Text>
                <Image
                  source={require("../assets/images/sample.png")}
                  resizeMode="contain"
                  style={styles.image4}
                ></Image>
              </View>
            </View>
            <View style={styles.rect3}>
              <View style={styles.image3Row}>
                <Image
                  source={require("../assets/images/sample.png")}
                  resizeMode="contain"
                  style={styles.image3}
                ></Image>
                <Text style={styles.premiumWash}>Premium Wash</Text>
              </View>
            </View>
            <View style={styles.rect4}>
              <View style={styles.shoeCleaningRow}>
                <Text style={styles.shoeCleaning}>Shoe Cleaning</Text>
                <Image
                  source={require("../assets/images/sample.png")}
                  resizeMode="contain"
                  style={styles.image2}
                ></Image>
              </View>
            </View>
            <View style={styles.rect7}>
              <View style={styles.image7Row}>
                <Image
                  source={require("../assets/images/sample.png")}
                  resizeMode="contain"
                  style={styles.image7}
                ></Image>
                <Text style={styles.steamPress}>Steam Press</Text>
              </View>
            </View>
            <View style={styles.rect8}>
              <View style={styles.dryCleaningRow}>
                <Text style={styles.dryCleaning}>Dry Cleaning</Text>
                <Image
                  source={require("../assets/images/sample.png")}
                  resizeMode="contain"
                  style={styles.image6}
                ></Image>
              </View>
            </View>
            <View style={styles.rect10}>
              <View style={styles.image9Row}>
                <Image
                  source={require("../assets/images/sample.png")}
                  resizeMode="contain"
                  style={styles.image9}
                ></Image>
                <Text style={styles.washAndIron}>Wash and Iron</Text>
              </View>
            </View>
            <View style={styles.rect9}>
              <View style={styles.washAndFoldRow}>
                <Text style={styles.washAndFold}>Wash and Fold</Text>
                <Image
                  source={require("../assets/images/sample.png")}
                  resizeMode="contain"
                  style={styles.image8}
                ></Image>
              </View>
            </View>
          </ScrollView>
        </View>
      </View>
      <View style={styles.materialHeader4ColumnFiller}></View>
      <MaterialBasicFooter3
        style={styles.materialBasicFooter3}
      ></MaterialBasicFooter3>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(255,255,255,1)"
  },
  materialHeader4: {
    height: 56
  },
  scrollArea: {
    height: 584,
    backgroundColor: "rgba(220,242,253,1)"
  },
  scrollArea_contentContainerStyle: {
    height: 1042
  },
  materialCardWithTextOverImage1: {
    height: 326,
    width: 339,
    marginTop: 13,
    marginLeft: 10
  },
  selectService: {
    fontFamily: "roboto-700",
    color: "rgba(0,107,173,1)",
    height: 22,
    width: 118,
    fontSize: 18,
    marginTop: 19,
    alignSelf: "center"
  },
  rect5: {
    width: 323,
    height: 69,
    backgroundColor: "rgba(255,255,255,1)",
    borderRadius: 10,
    flexDirection: "row",
    marginTop: 29,
    alignSelf: "center"
  },
  image5: {
    width: 85,
    height: 57
  },
  carpetCleaning: {
    fontFamily: "roboto-regular",
    color: "rgba(18,18,18,1)",
    height: 27,
    width: 133,
    fontSize: 18,
    marginLeft: 47,
    marginTop: 15
  },
  image5Row: {
    height: 57,
    flexDirection: "row",
    flex: 1,
    marginRight: 38,
    marginLeft: 20,
    marginTop: 6
  },
  rect6: {
    width: 323,
    height: 69,
    backgroundColor: "rgba(255,255,255,1)",
    borderRadius: 10,
    flexDirection: "row",
    marginTop: 12,
    alignSelf: "center"
  },
  sofaDrycleaning: {
    fontFamily: "roboto-regular",
    color: "rgba(18,18,18,1)",
    height: 27,
    width: 148,
    fontSize: 18,
    marginTop: 14
  },
  image4: {
    width: 85,
    height: 57,
    marginLeft: 35
  },
  sofaDrycleaningRow: {
    height: 57,
    flexDirection: "row",
    flex: 1,
    marginRight: 28,
    marginLeft: 27,
    marginTop: 6
  },
  rect3: {
    width: 323,
    height: 69,
    backgroundColor: "rgba(255,255,255,1)",
    borderRadius: 10,
    flexDirection: "row",
    marginTop: 10,
    marginLeft: 20
  },
  image3: {
    width: 85,
    height: 57
  },
  premiumWash: {
    fontFamily: "roboto-regular",
    color: "rgba(18,18,18,1)",
    height: 27,
    width: 133,
    fontSize: 18,
    marginLeft: 47,
    marginTop: 15
  },
  image3Row: {
    height: 57,
    flexDirection: "row",
    flex: 1,
    marginRight: 39,
    marginLeft: 19,
    marginTop: 6
  },
  rect4: {
    width: 323,
    height: 69,
    backgroundColor: "rgba(255,255,255,1)",
    borderRadius: 10,
    flexDirection: "row",
    marginTop: 12,
    marginLeft: 18
  },
  shoeCleaning: {
    fontFamily: "roboto-regular",
    color: "rgba(18,18,18,1)",
    height: 27,
    width: 148,
    fontSize: 18,
    marginTop: 15
  },
  image2: {
    width: 85,
    height: 57,
    marginLeft: 35
  },
  shoeCleaningRow: {
    height: 57,
    flexDirection: "row",
    flex: 1,
    marginRight: 27,
    marginLeft: 28,
    marginTop: 6
  },
  rect7: {
    width: 323,
    height: 69,
    backgroundColor: "rgba(255,255,255,1)",
    borderRadius: 10,
    flexDirection: "row",
    marginTop: 11,
    alignSelf: "center"
  },
  image7: {
    width: 85,
    height: 57
  },
  steamPress: {
    fontFamily: "roboto-regular",
    color: "rgba(18,18,18,1)",
    height: 27,
    width: 133,
    fontSize: 18,
    marginLeft: 48,
    marginTop: 15
  },
  image7Row: {
    height: 57,
    flexDirection: "row",
    flex: 1,
    marginRight: 40,
    marginLeft: 17,
    marginTop: 6
  },
  rect8: {
    width: 323,
    height: 69,
    backgroundColor: "rgba(255,255,255,1)",
    borderRadius: 10,
    flexDirection: "row",
    marginTop: 12,
    alignSelf: "center"
  },
  dryCleaning: {
    fontFamily: "roboto-regular",
    color: "rgba(18,18,18,1)",
    height: 27,
    width: 148,
    fontSize: 18,
    marginTop: 15
  },
  image6: {
    width: 85,
    height: 57,
    marginLeft: 34
  },
  dryCleaningRow: {
    height: 57,
    flexDirection: "row",
    flex: 1,
    marginRight: 31,
    marginLeft: 25,
    marginTop: 6
  },
  rect10: {
    width: 323,
    height: 69,
    backgroundColor: "rgba(255,255,255,1)",
    borderRadius: 10,
    flexDirection: "row",
    marginTop: 12,
    marginLeft: 19
  },
  image9: {
    width: 85,
    height: 57
  },
  washAndIron: {
    fontFamily: "roboto-regular",
    color: "rgba(18,18,18,1)",
    height: 27,
    width: 133,
    fontSize: 18,
    marginLeft: 48,
    marginTop: 15
  },
  image9Row: {
    height: 57,
    flexDirection: "row",
    flex: 1,
    marginRight: 40,
    marginLeft: 17,
    marginTop: 6
  },
  rect9: {
    width: 323,
    height: 69,
    backgroundColor: "rgba(255,255,255,1)",
    borderRadius: 10,
    flexDirection: "row",
    marginTop: 12,
    marginLeft: 19
  },
  washAndFold: {
    fontFamily: "roboto-regular",
    color: "rgba(18,18,18,1)",
    height: 27,
    width: 148,
    fontSize: 18,
    marginTop: 15
  },
  image8: {
    width: 85,
    height: 57,
    marginLeft: 34
  },
  washAndFoldRow: {
    height: 57,
    flexDirection: "row",
    flex: 1,
    marginRight: 31,
    marginLeft: 25,
    marginTop: 6
  },
  materialHeader4Column: {
    marginTop: 24
  },
  materialHeader4ColumnFiller: {
    flex: 1
  },
  materialBasicFooter3: {
    height: 56
  }
});

export default HomePage;
