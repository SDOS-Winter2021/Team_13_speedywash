import React, { Component } from "react";
import { StyleSheet, View, Text } from "react-native";
import MaterialCommunityIconsIcon from "react-native-vector-icons/MaterialCommunityIcons";
import EntypoIcon from "react-native-vector-icons/Entypo";

function MaterialHeader4(props) {
  return (
    <View style={[styles.container, props.style]}>
      <View style={styles.textWrapper}>
        <Text numberOfLines={1} style={styles.speedyWashIndia}>
          SpeedyWash India
        </Text>
      </View>
      <MaterialCommunityIconsIcon
        name="bell"
        style={styles.icon2}
      ></MaterialCommunityIconsIcon>
      <EntypoIcon name="shopping-cart" style={styles.icon3}></EntypoIcon>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "rgba(0,107,173,1)",
    flexDirection: "row",
    alignItems: "center",
    padding: 4,
    justifyContent: "space-between",
    shadowColor: "#111",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.2,
    shadowRadius: 1.2,
    elevation: 3
  },
  textWrapper: {
    alignSelf: "flex-end",
    marginLeft: 16,
    marginBottom: 19
  },
  speedyWashIndia: {
    fontSize: 18,
    color: "#FFFFFF",
    backgroundColor: "transparent",
    lineHeight: 18
  },
  icon2: {
    color: "rgba(255,255,255,1)",
    fontSize: 30,
    marginLeft: 304,
    marginTop: 12
  },
  icon3: {
    color: "rgba(255,255,255,1)",
    fontSize: 30,
    marginLeft: -80,
    marginTop: 12
  }
});

export default MaterialHeader4;
